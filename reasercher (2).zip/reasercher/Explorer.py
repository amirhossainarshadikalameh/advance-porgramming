import os


def explore(ttype, address):
    data_dic=dict()
    w_file=os.walk(address)
    # print(list(w_file))
    for tuple in w_file:
        for file_name in tuple[2]:
            if '.' in file_name:
                name,formate=file_name.split('.')
                counter=0
                if formate.lower()==ttype.lower():
                    counter+=1
                    # data_dic[]
                if counter != 0 :
                    data_dic[tuple[0]]=counter
    

    return data_dic



    pass

print(explore("mkv", "sample_test_media"))